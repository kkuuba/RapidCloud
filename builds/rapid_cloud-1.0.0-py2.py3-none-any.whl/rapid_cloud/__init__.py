from __future__ import absolute_import
from .rapid_cloud import main

__version__ = "1.0.0"
__author__ = "Jakub Kupiec"
